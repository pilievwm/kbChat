import numpy as np
import openai
import pandas as pd

openai.api_key = "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"

EMBEDDING_MODEL = "text-embedding-ada-002"

df = pd.read_csv('data/all_articles.csv')
df['token_count'] = df['description'].apply(lambda x: len(x.split()))

df = df.set_index(["title"])

def get_embedding(text: str, model: str=EMBEDDING_MODEL) -> list[float]:
    result = openai.Embedding.create(
      model=model,
      input=text
    )
    return result["data"][0]["embedding"]

def compute_doc_embeddings(df: pd.DataFrame) -> dict[tuple[str, str], list[float]]:
    return {
        idx: get_embedding(r.description) for idx, r in df.iterrows()
    }

def save_embeddings_to_csv(embeddings: dict, fname: str):
    num_cols = len(list(embeddings.values())[0])
    columns = [str(i) for i in range(num_cols)]
    df = pd.DataFrame.from_dict(embeddings, orient='index', columns=columns)
    df.index.name = "description"  # Add this line to set the index name
    df.reset_index(inplace=True)
    df.to_csv(fname, index=False)

embeddings = compute_doc_embeddings(df)
save_embeddings_to_csv(embeddings, "data/embeddings.csv")

